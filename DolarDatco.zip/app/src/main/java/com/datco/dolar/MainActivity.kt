package com.datco.dolar

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Currency
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF1B2028)
private val CardC = Color(0xFF252C37)
private val Cyan = Color(0xFF00D2FF)
private val Muted = Color(0xFF9AA5B4)
private val AR = Locale("es", "AR")

data class Quote(val casa: String, val name: String, val buy: Double?, val sell: Double?)

fun fetch(u: String): String {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 8000; c.readTimeout = 8000
    return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
}

fun parseRates(s: String?): Map<String, Double> = runCatching {
    val o = JSONObject(s!!).getJSONObject("rates")
    o.keys().asSequence().associateWith { k -> o.getDouble(k) }
}.getOrDefault(emptyMap())

fun parseQuotes(s: String?): List<Quote> = runCatching {
    val a = JSONArray(s!!)
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        Quote(
            o.optString("casa"), o.optString("nombre"),
            o.optDouble("compra").takeIf { v -> !v.isNaN() },
            o.optDouble("venta").takeIf { v -> !v.isNaN() }
        )
    }
}.getOrDefault(emptyList())

fun parseHist(s: String): List<Pair<String, Double>> = s.split(",").mapNotNull { p ->
    val x = p.split(":")
    val v = x.getOrNull(1)?.toDoubleOrNull()
    if (x.size == 2 && v != null) x[0] to v else null
}

fun nameOf(c: String): String = runCatching { Currency.getInstance(c).displayName }.getOrDefault(c)

fun flag(code: String): String {
    val c = if (code == "EUR") "EU" else code.take(2)
    if (c.length != 2 || !c.all { it in 'A'..'Z' }) return "🏳️"
    return String(Character.toChars(0x1F1E6 + (c[0] - 'A'))) + String(Character.toChars(0x1F1E6 + (c[1] - 'A')))
}

fun fmt(v: Double): String = String.format(AR, if (v >= 1) "%,.2f" else "%,.6f", v)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = CardC)) {
                var splash by remember { mutableStateOf(true) }
                if (splash) Splash { splash = false } else Home(applicationContext)
            }
        }
    }
}

@Composable
fun Splash(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(900)); delay(1100); onDone() }
    Column(
        Modifier.fillMaxSize().background(Bg).padding(24.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.alpha(a.value).scale(0.8f + 0.2f * a.value).size(96.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
            Alignment.Center
        ) { Text("D", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        Spacer(Modifier.height(20.dp))
        Text("DATCO", Modifier.alpha(a.value), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 8.sp)
        Spacer(Modifier.height(6.dp))
        Text("Desarrollo Avanzado de Tecnologías y Códigos Operativos", Modifier.alpha(a.value), color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(48.dp))
        Text("Diseño de apps... y algo más", Modifier.alpha(a.value), color = Cyan, fontSize = 13.sp)
    }
}

@Composable
fun Home(ctx: Context) {
    val sp = remember { ctx.getSharedPreferences("dolar", Context.MODE_PRIVATE) }
    var rates by remember { mutableStateOf(parseRates(sp.getString("rates", null))) }
    var quotes by remember { mutableStateOf(parseQuotes(sp.getString("quotes", null))) }
    var hist by remember { mutableStateOf(parseHist(sp.getString("hist", "") ?: "")) }
    var ts by remember { mutableStateOf(sp.getLong("ts", 0L)) }
    var from by remember { mutableStateOf(sp.getString("from", "USD") ?: "USD") }
    var to by remember { mutableStateOf(sp.getString("to", "ARS") ?: "ARS") }
    var amount by remember { mutableStateOf("1") }
    var loading by remember { mutableStateOf(false) }
    var offline by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf<Int?>(null) }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch {
            loading = true
            val pair = withContext(Dispatchers.IO) {
                runCatching { fetch("https://open.er-api.com/v6/latest/USD") to runCatching { fetch("https://dolarapi.com/v1/dolares") }.getOrNull() }
            }.getOrNull()
            val r = parseRates(pair?.first)
            if (pair == null || r.isEmpty()) offline = true else {
                offline = false; rates = r; ts = System.currentTimeMillis()
                val e = sp.edit().putString("rates", pair.first).putLong("ts", ts)
                val q = parseQuotes(pair.second)
                if (q.isNotEmpty()) {
                    quotes = q; e.putString("quotes", pair.second)
                    q.firstOrNull { it.casa == "blue" }?.sell?.let { b ->
                        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                        hist = (hist.filter { it.first != day } + (day to b)).takeLast(14)
                        e.putString("hist", hist.joinToString(",") { "${it.first}:${it.second}" })
                    }
                }
                e.apply()
            }
            loading = false
        }
    }

    LaunchedEffect(Unit) { if (System.currentTimeMillis() - ts > 1_800_000) refresh() }
    LaunchedEffect(from, to) { sp.edit().putString("from", from).putString("to", to).apply() }

    val codes = remember(rates) {
        val top = listOf("ARS", "USD", "EUR", "BRL", "JPY", "GBP")
        rates.keys.sortedWith(compareBy({ k -> top.indexOf(k).let { i -> if (i < 0) 99 else i } }, { k -> k }))
    }
    val a = amount.replace(',', '.').toDoubleOrNull()
    val rf = rates[from]; val rt = rates[to]
    val result = if (a != null && rf != null && rt != null) a / rf * rt else null

    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Column {
                Text("Dólar y monedas", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    (if (ts == 0L) "Sin datos" else "Actualizado: " + SimpleDateFormat("dd/MM HH:mm", AR).format(Date(ts))) +
                        (if (offline) " · sin conexión" else ""),
                    color = Muted, fontSize = 12.sp
                )
            }
            TextButton(onClick = { if (!loading) refresh() }) { Text(if (loading) "…" else "↻", color = Cyan, fontSize = 26.sp) }
        }
        Spacer(Modifier.height(12.dp))

        Card(colors = CardDefaults.cardColors(containerColor = CardC), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { picking = 0 }, modifier = Modifier.weight(1f)) { Text("${flag(from)} $from", fontSize = 18.sp) }
                    TextButton(onClick = { val t = from; from = to; to = t }) { Text("⇄", color = Cyan, fontSize = 24.sp) }
                    OutlinedButton(onClick = { picking = 1 }, modifier = Modifier.weight(1f)) { Text("${flag(to)} $to", fontSize = 18.sp) }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    amount, { amount = it }, Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("Monto") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Spacer(Modifier.height(12.dp))
                if (rates.isEmpty()) {
                    Text("Conectate a internet para cargar las cotizaciones la primera vez.", color = Muted)
                } else {
                    Text(result?.let { "${fmt(it)} $to" } ?: "—", color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    if (rf != null && rt != null) Text("1 $from = ${fmt(rt / rf)} $to", color = Muted, fontSize = 13.sp)
                }
            }
        }

        if (quotes.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = CardC), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Dólar en Argentina", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Spacer(Modifier.weight(1f))
                        Text("Compra", Modifier.width(80.dp), color = Muted, fontSize = 12.sp, textAlign = TextAlign.End)
                        Text("Venta", Modifier.width(80.dp), color = Muted, fontSize = 12.sp, textAlign = TextAlign.End)
                    }
                    quotes.forEach { q ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(q.name, Modifier.weight(1f), color = Color.White)
                            Text(q.buy?.let { "$ " + fmt(it) } ?: "—", Modifier.width(80.dp), color = Muted, textAlign = TextAlign.End, fontSize = 13.sp)
                            Text(q.sell?.let { "$ " + fmt(it) } ?: "—", Modifier.width(80.dp), color = Cyan, textAlign = TextAlign.End, fontSize = 13.sp)
                        }
                    }
                    if (hist.size >= 2) {
                        Spacer(Modifier.height(12.dp))
                        Text("Blue (venta) · últimos ${hist.size} días", color = Muted, fontSize = 12.sp)
                        Spark(hist.map { it.second })
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    val p = picking
    if (p != null) Picker(codes, { c -> if (p == 0) from = c else to = c; picking = null }, { picking = null })
}

@Composable
fun Spark(v: List<Double>) {
    val mn = v.min(); val mx = v.max()
    val rng = if (mx - mn > 0) mx - mn else 1.0
    Canvas(Modifier.fillMaxWidth().height(70.dp).padding(vertical = 6.dp)) {
        val step = size.width / (v.size - 1)
        val pts = v.mapIndexed { i, y -> Offset(i * step, (size.height * (1 - (y - mn) / rng)).toFloat()) }
        for (i in 0 until pts.size - 1) drawLine(Cyan, pts[i], pts[i + 1], 4f)
    }
}

@Composable
fun Picker(codes: List<String>, onPick: (String) -> Unit, onClose: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(q, codes) { codes.filter { q.isBlank() || it.contains(q, true) || nameOf(it).contains(q, true) } }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Cerrar") } },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, singleLine = true, placeholder = { Text("Buscar moneda") })
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.height(320.dp)) {
                    items(list) { c ->
                        Text("${flag(c)}  $c  ·  ${nameOf(c)}", Modifier.fillMaxWidth().clickable { onPick(c) }.padding(vertical = 10.dp), fontSize = 15.sp)
                    }
                }
            }
        }
    )
}
